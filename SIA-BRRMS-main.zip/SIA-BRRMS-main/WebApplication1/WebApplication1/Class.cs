﻿namespace WebApplication1
{
    public class Class
    {
    }
}
